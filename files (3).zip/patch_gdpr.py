#!/usr/bin/env python3
"""
GALAXY GDPR Patcher
Run: python3 patch_gdpr.py index.html
Output: index-gdpr.html (deploy this to Cloudflare R2 as index.html)

Files needed in same folder:
  - gdpr_pages.html
  - gdpr_script.html
"""
import sys, os

if len(sys.argv) < 2:
    print("Usage: python3 patch_gdpr.py index.html")
    sys.exit(1)

here = os.path.dirname(os.path.abspath(__file__))
src = sys.argv[1]

with open(src, encoding='utf-8') as f:
    html = f.read()
print(f"Read {len(html):,} chars from {src}")

with open(os.path.join(here, 'gdpr_pages.html'), encoding='utf-8') as f:
    gdpr_pages = f.read()
with open(os.path.join(here, 'gdpr_script.html'), encoding='utf-8') as f:
    gdpr_script = f.read()

# 1. GDPR pages before bottom nav
A1 = '<!-- BOTTOM NAV (mobile) -->'
if A1 not in html:
    print("ERROR: anchor not found:", repr(A1))
    sys.exit(1)
html = html.replace(A1, gdpr_pages + '\n' + A1, 1)
print("OK  GDPR pages (privacy policy, terms, cookie banner)")

# 2. Privacy + Terms tabs in desktop nav
A2 = '    <button class="nav-tab" onclick="goAdmin(this)" id="tab-admin" style="display:none">\u2699\ufe0f Admin</button>'
NAV_TABS = (
    '    <button class="nav-tab" onclick="showPage(\'privacy\',this)" id="tab-privacy">Privacy</button>\n'
    '    <button class="nav-tab" onclick="showPage(\'terms\',this)" id="tab-terms">Terms</button>'
)
if A2 in html:
    html = html.replace(A2, A2 + '\n' + NAV_TABS, 1)
    print("OK  Privacy + Terms nav tabs added")
else:
    print("WARN nav tab anchor not found")

# 3. GDPR consent text in signup modal
A3 = '    <button class="modal-btn" id="su-btn" onclick="doSignup()">Create account \u2192</button>'
CONSENT = (
    '    <div style="font-size:.73rem;color:var(--muted);margin-bottom:10px;line-height:1.5">'
    'By creating an account you agree to our '
    '<a onclick="closeModal();showPage(\'terms\',null)" style="color:var(--accent);cursor:pointer;text-decoration:underline">Terms of Service</a>'
    ' and '
    '<a onclick="closeModal();showPage(\'privacy\',null)" style="color:var(--accent);cursor:pointer;text-decoration:underline">Privacy Policy</a>.'
    '</div>'
)
if A3 in html:
    html = html.replace(A3, CONSENT + '\n' + A3, 1)
    print("OK  Signup consent text added")
else:
    # Try without unicode arrow
    A3b = '    <button class="modal-btn" id="su-btn" onclick="doSignup()">Create account &rarr;</button>'
    if A3b in html:
        html = html.replace(A3b, CONSENT + '\n' + A3b, 1)
        print("OK  Signup consent text added (arrow variant)")
    else:
        print("WARN signup anchor not found")

# 4. GDPR script before </body>
html = html.replace('</body>', gdpr_script + '\n</body>', 1)
print("OK  GDPR JavaScript added")

# 5. Build tag
html = html.replace('<!-- build: 20260513-190001 -->', '<!-- build: 20260608-gdpr -->')
print("OK  Build tag updated")

# Write
out = os.path.join(os.path.dirname(src), 'index-gdpr.html')
with open(out, 'w', encoding='utf-8') as f:
    f.write(html)
print(f"\nDone: {out}  ({len(html):,} chars)")
print("Deploy as index.html to Cloudflare R2")
