-- Run this with: wrangler d1 execute vino-realty-db --file=schema.sql

CREATE TABLE IF NOT EXISTS properties (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  location TEXT NOT NULL,
  province TEXT,
  price REAL NOT NULL,
  beds INTEGER DEFAULT 0,
  baths INTEGER DEFAULT 0,
  area_num REAL,
  area TEXT,
  land TEXT,
  lp INTEGER DEFAULT 0,
  img TEXT,
  emoji TEXT,
  amenities TEXT,      -- JSON array stored as text
  deed TEXT,
  badge TEXT,
  badge_key TEXT,
  description TEXT,
  photos TEXT,         -- JSON array of R2 public URLs
  mode TEXT DEFAULT 'sale',
  boosted INTEGER DEFAULT 0,
  boosted_until TEXT,
  boosted_days INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS user_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phone TEXT UNIQUE NOT NULL,
  name TEXT,
  password TEXT,
  ref_code TEXT UNIQUE,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS ad_submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref_code TEXT,
  name TEXT,
  phone TEXT,
  type TEXT,
  title TEXT,
  location TEXT,
  province TEXT,
  price REAL,
  beds INTEGER,
  baths INTEGER,
  area TEXT,
  land TEXT,
  deed TEXT,
  description TEXT,
  amenities TEXT,
  photos TEXT,         -- JSON array of R2 public URLs
  mode TEXT DEFAULT 'sale',
  package TEXT,
  badge TEXT,
  status TEXT DEFAULT 'pending',
  created_at TEXT DEFAULT (datetime('now'))
);
