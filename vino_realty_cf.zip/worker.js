/**
 * vino.properties — Cloudflare Worker API
 * Replaces Supabase with D1 (database) + R2 (photo storage)
 *
 * Routes:
 *   GET    /api/properties              list all properties
 *   POST   /api/properties              create property (admin)
 *   PUT    /api/properties/:id          update property (admin)
 *   DELETE /api/properties/:id          delete property (admin)
 *   POST   /api/properties/:id/boost    boost a property
 *
 *   GET    /api/submissions             list pending submissions (admin)
 *   POST   /api/submissions             submit a listing ad
 *   POST   /api/submissions/:id/approve approve submission → create property
 *   POST   /api/submissions/:id/reject  reject submission
 *
 *   POST   /api/users/register          register / get ref code
 *   POST   /api/users/login             login
 *   GET    /api/users/:phone/submissions get user's submissions
 *
 *   POST   /api/photos                  upload base64 photos → R2, return URLs
 */

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' },
  });
}

function err(msg, status = 400) {
  return json({ error: msg }, status);
}

/** Upload base64 photos to R2, return array of public URLs */
async function uploadPhotos(env, photos, prefix = 'prop') {
  const urls = [];
  for (let i = 0; i < photos.length; i++) {
    const photo = photos[i];
    // photo is either a data URL ("data:image/jpeg;base64,...") or a URL already
    if (!photo || typeof photo !== 'string') continue;
    if (photo.startsWith('http')) {
      urls.push(photo); // already a URL, keep it
      continue;
    }
    // Parse data URL
    const match = photo.match(/^data:([^;]+);base64,(.+)$/);
    if (!match) continue;
    const [, mimeType, b64] = match;
    const ext = mimeType.split('/')[1]?.replace('jpeg', 'jpg') || 'jpg';
    const key = `${prefix}-${Date.now()}-${i}.${ext}`;
    const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
    await env.PHOTOS.put(key, bytes, { httpMetadata: { contentType: mimeType } });
    // Public URL — uses the R2 public bucket URL you configure in the dashboard
    const publicBase = env.R2_PUBLIC_URL || `https://pub-vino.r2.dev`; // set this in wrangler vars
    urls.push(`${publicBase}/${key}`);
  }
  return urls;
}

/** Parse JSON body safely */
async function body(req) {
  try { return await req.json(); } catch { return {}; }
}

/** Generate a ref code */
function makeRef() {
  return 'VN' + Math.random().toString(36).slice(2, 8).toUpperCase();
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const { pathname } = url;
    const method = req.method.toUpperCase();

    // CORS preflight
    if (method === 'OPTIONS') {
      return new Response(null, { headers: CORS });
    }

    // ── Photos ─────────────────────────────────────────────────────────────
    if (pathname === '/api/photos' && method === 'POST') {
      const { photos = [], prefix } = await body(req);
      const urls = await uploadPhotos(env, photos, prefix || 'photo');
      return json({ urls });
    }

    // ── Properties ─────────────────────────────────────────────────────────
    if (pathname === '/api/properties') {
      if (method === 'GET') {
        const { results } = await env.DB.prepare(
          `SELECT * FROM properties ORDER BY boosted DESC, created_at DESC`
        ).all();
        // Parse JSON fields
        const props = results.map(r => ({
          ...r,
          amenities: safeJson(r.amenities, []),
          photos: safeJson(r.photos, []),
        }));
        return json({ data: props });
      }

      if (method === 'POST') {
        const d = await body(req);
        const photos = d.photos?.length
          ? await uploadPhotos(env, d.photos, 'prop')
          : [];
        const stmt = env.DB.prepare(`
          INSERT INTO properties
            (type,title,location,province,price,beds,baths,area_num,area,land,lp,img,emoji,amenities,deed,badge,badge_key,description,photos,mode,boosted,boosted_until,boosted_days,created_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))
        `);
        const r = await stmt.bind(
          d.type, d.title, d.location, d.province ?? null,
          d.price, d.beds ?? 0, d.baths ?? 0, d.areaNum ?? null,
          d.area ?? null, d.land ?? null, d.lp ?? 0,
          d.img ?? null, d.emoji ?? null,
          JSON.stringify(d.amenities ?? []),
          d.deed ?? null, d.badge ?? null, d.badge_key ?? null,
          d.description ?? null,
          JSON.stringify(photos),
          d.mode ?? 'sale',
          d.boosted ? 1 : 0,
          d.boosted_until ?? null,
          d.boosted_days ?? 0,
        ).run();
        return json({ data: { id: r.meta.last_row_id } }, 201);
      }
    }

    // ── Properties/:id ─────────────────────────────────────────────────────
    const propMatch = pathname.match(/^\/api\/properties\/(\d+)(\/.*)?$/);
    if (propMatch) {
      const id = parseInt(propMatch[1]);
      const sub = propMatch[2] || '';

      if (sub === '/boost' && method === 'POST') {
        const { days } = await body(req);
        const d = parseInt(days) || 7;
        const until = new Date(Date.now() + d * 86400000).toISOString();
        await env.DB.prepare(
          `UPDATE properties SET boosted=1, boosted_until=?, boosted_days=? WHERE id=?`
        ).bind(until, d, id).run();
        return json({ ok: true });
      }

      if (method === 'PUT') {
        const d = await body(req);
        // Handle photo upload if new base64 photos provided
        let photos = d.photos;
        if (Array.isArray(photos)) {
          photos = await uploadPhotos(env, photos, `prop-${id}`);
        }
        const sets = [];
        const vals = [];
        const allowed = ['type','title','location','province','price','beds','baths',
          'area_num','area','land','lp','img','emoji','deed','badge','badge_key',
          'description','mode','boosted','boosted_until','boosted_days'];
        for (const k of allowed) {
          if (d[k] !== undefined) { sets.push(`${k}=?`); vals.push(d[k]); }
        }
        // Map camelCase
        if (d.areaNum !== undefined) { sets.push('area_num=?'); vals.push(d.areaNum); }
        if (d.amenities !== undefined) { sets.push('amenities=?'); vals.push(JSON.stringify(d.amenities)); }
        if (photos !== undefined) { sets.push('photos=?'); vals.push(JSON.stringify(photos)); }
        sets.push(`created_at=datetime('now')`); // refresh timestamp for sorting
        vals.push(id);
        if (sets.length > 1) {
          await env.DB.prepare(`UPDATE properties SET ${sets.join(',')} WHERE id=?`)
            .bind(...vals).run();
        }
        return json({ ok: true });
      }

      if (method === 'DELETE') {
        await env.DB.prepare(`DELETE FROM properties WHERE id=?`).bind(id).run();
        return json({ ok: true });
      }
    }

    // ── Submissions ─────────────────────────────────────────────────────────
    if (pathname === '/api/submissions') {
      if (method === 'GET') {
        const { results } = await env.DB.prepare(
          `SELECT * FROM ad_submissions WHERE status='pending' ORDER BY created_at DESC`
        ).all();
        const subs = results.map(r => ({
          ...r,
          amenities: safeJson(r.amenities, []),
          photos: safeJson(r.photos, []),
        }));
        return json({ data: subs });
      }

      if (method === 'POST') {
        const d = await body(req);
        const photos = d.photos?.length
          ? await uploadPhotos(env, d.photos, 'sub')
          : [];
        const r = await env.DB.prepare(`
          INSERT INTO ad_submissions
            (ref_code,name,phone,type,title,location,province,price,beds,baths,area,land,deed,description,amenities,photos,mode,package,badge,status,created_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',datetime('now'))
        `).bind(
          d.ref_code ?? null, d.name ?? null, d.phone ?? null,
          d.type, d.title, d.location, d.province ?? null,
          d.price, d.beds ?? 0, d.baths ?? 0,
          d.area ?? null, d.land ?? null, d.deed ?? null,
          d.description ?? null,
          JSON.stringify(d.amenities ?? []),
          JSON.stringify(photos),
          d.mode ?? 'sale',
          d.package ?? null,
          d.badge ?? null,
        ).run();
        return json({ data: { id: r.meta.last_row_id } }, 201);
      }
    }

    const subMatch = pathname.match(/^\/api\/submissions\/(\d+)\/(approve|reject)$/);
    if (subMatch && method === 'POST') {
      const id = parseInt(subMatch[1]);
      const action = subMatch[2];
      const status = action === 'approve' ? 'approved' : 'rejected';
      await env.DB.prepare(`UPDATE ad_submissions SET status=? WHERE id=?`).bind(status, id).run();

      if (action === 'approve') {
        // Copy submission into properties table
        const sub = await env.DB.prepare(`SELECT * FROM ad_submissions WHERE id=?`).bind(id).first();
        if (sub) {
          const { results: pkg } = await env.DB.prepare(
            `SELECT badge, badge_key FROM ad_submissions WHERE id=?`
          ).bind(id).all();
          await env.DB.prepare(`
            INSERT INTO properties
              (type,title,location,province,price,beds,baths,area,land,deed,description,amenities,photos,mode,badge,badge_key,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))
          `).bind(
            sub.type, sub.title, sub.location, sub.province,
            sub.price, sub.beds, sub.baths,
            sub.area, sub.land, sub.deed, sub.description,
            sub.amenities, sub.photos,
            sub.mode ?? 'sale',
            sub.badge, sub.badge,
          ).run();
        }
      }
      return json({ ok: true });
    }

    // ── Users ───────────────────────────────────────────────────────────────
    if (pathname === '/api/users/register' && method === 'POST') {
      const { phone, name, password } = await body(req);
      if (!phone) return err('phone required');
      const existing = await env.DB.prepare(
        `SELECT id, ref_code FROM user_accounts WHERE phone=?`
      ).bind(phone).first();
      if (existing) {
        // Update password if provided
        if (password) {
          await env.DB.prepare(`UPDATE user_accounts SET password=? WHERE phone=?`).bind(password, phone).run();
        }
        return json({ data: existing });
      }
      const ref = makeRef();
      const r = await env.DB.prepare(
        `INSERT INTO user_accounts (phone,name,password,ref_code,created_at) VALUES (?,?,?,?,datetime('now'))`
      ).bind(phone, name ?? null, password ?? null, ref).run();
      return json({ data: { id: r.meta.last_row_id, ref_code: ref } }, 201);
    }

    if (pathname === '/api/users/login' && method === 'POST') {
      const { phone, password } = await body(req);
      const user = await env.DB.prepare(
        `SELECT * FROM user_accounts WHERE phone=? AND password=?`
      ).bind(phone, password).first();
      if (!user) return err('Invalid credentials', 401);
      return json({ data: user });
    }

    const userSubMatch = pathname.match(/^\/api\/users\/([^/]+)\/submissions$/);
    if (userSubMatch && method === 'GET') {
      const refCode = decodeURIComponent(userSubMatch[1]);
      const { results } = await env.DB.prepare(
        `SELECT * FROM ad_submissions WHERE ref_code=? ORDER BY created_at DESC`
      ).bind(refCode).all();
      return json({ data: results.map(r => ({ ...r, photos: safeJson(r.photos, []) })) });
    }

    // ── 404 ────────────────────────────────────────────────────────────────
    if (pathname.startsWith('/api/')) {
      return err('Not found', 404);
    }

    // Serve static assets (handled by Workers Assets)
    return new Response('Not found', { status: 404 });
  },
};

function safeJson(str, fallback) {
  if (!str) return fallback;
  try { return JSON.parse(str); } catch { return fallback; }
}
