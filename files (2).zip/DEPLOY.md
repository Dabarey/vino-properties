# vino.properties — Cloudflare Deployment Guide

## What you get
| Storage    | What's in it                          |
|------------|---------------------------------------|
| **R2**     | Property photos (images)              |
| **D1**     | Everything else — properties, ad submissions, user accounts |
| **Worker** | Serves index.html + all API routes    |

---

## 1. Install Wrangler

```bash
npm install
# or globally:
npm install -g wrangler
wrangler login
```

---

## 2. Create R2 bucket

```bash
npm run r2:create
# Creates: vino-images
```

---

## 3. Create D1 database

```bash
npm run db:create
```

Copy the **database_id** from the output and paste it into `wrangler.toml`:

```toml
[[d1_databases]]
database_id = "PASTE_YOUR_ID_HERE"
```

---

## 4. Create the D1 tables

```bash
# Local (for wrangler dev):
npm run db:init

# Remote (production):
npm run db:init:remote
```

---

## 5. Deploy

```bash
npm run deploy
```

Your worker will be live at:
`https://vino.<your-cf-account>.workers.dev`

Since you connected GitHub, every push to `main` will auto-deploy via the
Cloudflare Pages/Workers integration you set up.

---

## 6. Custom domain (vino.daba-rey3.workers.dev is already set)

The worker is automatically available at:
**`https://vino.daba-rey3.workers.dev`**

To add a custom domain (e.g. `vino.properties`):
1. Cloudflare Dashboard → Workers & Pages → vino → Settings → Domains & Routes
2. Add Route: `vino.properties/*`

---

## GitHub Actions (CI/CD) — optional

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy Worker
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: cloudflare/wrangler-action@v3
        with:
          apiToken: ${{ secrets.CF_API_TOKEN }}
```

Add `CF_API_TOKEN` in your GitHub repo → Settings → Secrets.

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/properties` | List all live properties |
| POST | `/api/properties` | Add property (admin) |
| PUT | `/api/properties/:id` | Update property (admin) |
| DELETE | `/api/properties/:id` | Delete property (admin) |
| PUT | `/api/properties/:id/boost` | Boost property `{ days: 7 }` |
| GET | `/api/submissions` | List pending submissions (admin) |
| POST | `/api/submissions` | Submit new ad (public) |
| PUT | `/api/submissions/:id/approve` | Approve submission |
| PUT | `/api/submissions/:id/reject` | Reject submission |
| POST | `/api/users/login` | Phone + password login |
| POST | `/api/users/register` | Create account |
| POST | `/api/users/google` | Google OAuth login |
| GET | `/api/users/ads?ref_code=X` | User's own ads |
| POST | `/api/images/upload` | Upload photos to R2 |
| GET | `/images/:key` | Serve photo from R2 |

---

## Photo flow

1. User picks photos in browser (becomes `base64` in JS)
2. `db.from('properties').insert({..., photos: [base64, ...]})` hits `/api/properties` POST
3. Worker calls `uploadPhotosArray()` — each base64 is stored in R2
4. Worker saves the **R2 public URL** (`/images/photos/...`) to D1
5. Browser gets back the URL and renders `<img src="/images/...">`
