/**
 * vino.properties — Cloudflare Worker
 * Images  → R2 bucket (VINO_IMAGES)
 * All data → D1 database (VINO_DB)
 *
 * Routes:
 *   GET  /                          → serve index.html
 *   GET  /images/:key               → serve image from R2
 *   POST /api/images/upload         → upload image(s) to R2, returns URLs
 *
 *   GET  /api/properties            → list properties
 *   POST /api/properties            → insert property  (admin)
 *   PUT  /api/properties/:id        → update property  (admin)
 *   DELETE /api/properties/:id      → delete property  (admin)
 *
 *   GET  /api/submissions           → list pending ad submissions (admin)
 *   POST /api/submissions           → submit a new ad
 *   PUT  /api/submissions/:id/approve → approve submission
 *   PUT  /api/submissions/:id/reject  → reject submission
 *
 *   GET  /api/users                 → (admin) list users
 *   POST /api/users/login           → phone+password login
 *   POST /api/users/register        → create account
 *   POST /api/users/google          → google login/register
 *   GET  /api/users/ads?ref_code=   → user's own submissions
 */

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // ── CORS preflight ──────────────────────────────────────────────────────
    if (method === 'OPTIONS') {
      return cors(new Response(null, { status: 204 }));
    }

    try {
      // ── Static: serve index.html ──────────────────────────────────────────
      if (path === '/' || path === '/index.html') {
        const html = await env.ASSETS.get('index.html', 'text');
        if (html) {
          return cors(new Response(html, { headers: { 'Content-Type': 'text/html;charset=UTF-8' } }));
        }
        return cors(new Response('Not found', { status: 404 }));
      }

      // ── R2 image serving ──────────────────────────────────────────────────
      if (path.startsWith('/images/')) {
        const key = decodeURIComponent(path.slice('/images/'.length));
        const obj = await env.VINO_IMAGES.get(key);
        if (!obj) return cors(new Response('Image not found', { status: 404 }));
        const headers = new Headers();
        obj.writeHttpMetadata(headers);
        headers.set('Cache-Control', 'public, max-age=31536000, immutable');
        return cors(new Response(obj.body, { headers }));
      }

      // ── API routes ────────────────────────────────────────────────────────
      if (path.startsWith('/api/')) {
        return await handleAPI(request, env, url, path, method);
      }

      return cors(new Response('Not found', { status: 404 }));

    } catch (err) {
      console.error(err);
      return cors(json({ error: err.message }, 500));
    }
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// API router
// ─────────────────────────────────────────────────────────────────────────────
async function handleAPI(request, env, url, path, method) {
  const db = env.VINO_DB;

  // ── Image upload ──────────────────────────────────────────────────────────
  if (path === '/api/images/upload' && method === 'POST') {
    const body = await request.json();
    // body: { images: [ { name: 'photo1.jpg', data: 'data:image/jpeg;base64,...' } ] }
    const results = [];
    for (const img of (body.images || [])) {
      const key = await uploadImageToR2(env.VINO_IMAGES, img.data, img.name);
      const publicUrl = `${url.origin}/images/${key}`;
      results.push(publicUrl);
    }
    return cors(json({ urls: results }));
  }

  // ── Properties ────────────────────────────────────────────────────────────
  if (path === '/api/properties') {
    if (method === 'GET') {
      const { results } = await db.prepare(
        'SELECT * FROM properties ORDER BY boosted DESC, boosted_until DESC, created_at DESC'
      ).all();
      // Parse JSON columns
      return cors(json(results.map(parseProperty)));
    }
    if (method === 'POST') {
      const body = await request.json();
      // Upload photos first, replace base64 with R2 URLs
      body.photos = await uploadPhotosArray(env.VINO_IMAGES, url, body.photos);
      const id = await insertProperty(db, body);
      return cors(json({ id }), 201);
    }
  }

  const propMatch = path.match(/^\/api\/properties\/(\d+)$/);
  if (propMatch) {
    const id = propMatch[1];
    if (method === 'PUT') {
      const body = await request.json();
      body.photos = await uploadPhotosArray(env.VINO_IMAGES, url, body.photos);
      await updateProperty(db, id, body);
      return cors(json({ ok: true }));
    }
    if (method === 'DELETE') {
      await db.prepare('DELETE FROM properties WHERE id = ?').bind(id).run();
      return cors(json({ ok: true }));
    }
  }

  // ── Ad Submissions ────────────────────────────────────────────────────────
  if (path === '/api/submissions') {
    if (method === 'GET') {
      const { results } = await db.prepare(
        "SELECT * FROM ad_submissions WHERE status = 'pending' ORDER BY created_at DESC"
      ).all();
      return cors(json(results.map(parseProperty)));
    }
    if (method === 'POST') {
      const body = await request.json();
      body.photos = await uploadPhotosArray(env.VINO_IMAGES, url, body.photos);
      const refCode = body.ref_code || generateRef();
      const stmt = db.prepare(`
        INSERT INTO ad_submissions
          (title,type,price,location,province,beds,baths,area,land,land_perches,
           img,amenities,deed,listing_mode,badge,badge_key,description,status,
           submitter_name,submitter_phone,submitter_email,country,
           package_name,package_price,payment_ref,ref_code,photos,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      `);
      const r = await stmt.bind(
        body.title, body.type, body.price, body.location, body.province||'',
        body.beds||0, body.baths||0, body.area||'—', body.land||'—', body.land_perches||0,
        body.img||'img-custom', JSON.stringify(body.amenities||[]),
        body.deed||'freehold', body.listing_mode||'buy',
        body.badge||null, body.badge_key||null, body.description||'',
        'pending',
        body.submitter_name||'', body.submitter_phone||'', body.submitter_email||'',
        body.country||'LK',
        body.package_name||'basic', body.package_price||2900, body.payment_ref||'',
        refCode, JSON.stringify(body.photos||[]),
        new Date().toISOString()
      ).run();
      return cors(json({ ref_code: refCode }), 201);
    }
  }

  const approveMatch = path.match(/^\/api\/submissions\/(\d+)\/(approve|reject)$/);
  if (approveMatch && method === 'PUT') {
    const [, id, action] = approveMatch;
    if (action === 'approve') {
      const sub = await db.prepare('SELECT * FROM ad_submissions WHERE id = ?').bind(id).first();
      if (!sub) return cors(json({ error: 'Not found' }, 404));
      const s = parseProperty(sub);
      await insertProperty(db, {
        ...s,
        badge: s.badge || null,
        status: undefined,
        submitter_name: undefined,
        submitter_phone: undefined,
        submitter_email: undefined,
        package_name: undefined,
        package_price: undefined,
        payment_ref: undefined,
        ref_code: undefined,
      });
      await db.prepare("UPDATE ad_submissions SET status='approved' WHERE id=?").bind(id).run();
    } else {
      await db.prepare("UPDATE ad_submissions SET status='rejected' WHERE id=?").bind(id).run();
    }
    return cors(json({ ok: true }));
  }

  // ── Users ─────────────────────────────────────────────────────────────────
  if (path === '/api/users/login' && method === 'POST') {
    const { phone, password } = await request.json();
    const user = await db.prepare(
      'SELECT * FROM user_accounts WHERE phone=? AND password=?'
    ).bind(phone, password).first();
    if (!user) return cors(json({ error: 'Invalid credentials' }, 401));
    return cors(json(user));
  }

  if (path === '/api/users/register' && method === 'POST') {
    const { phone, name, password, ref_code } = await request.json();
    const existing = await db.prepare('SELECT id FROM user_accounts WHERE phone=?').bind(phone).first();
    const ref = ref_code || generateRef();
    if (existing) {
      await db.prepare('UPDATE user_accounts SET password=?, ref_code=? WHERE phone=?').bind(password, ref, phone).run();
      const u = await db.prepare('SELECT * FROM user_accounts WHERE phone=?').bind(phone).first();
      return cors(json(u));
    }
    await db.prepare(
      'INSERT INTO user_accounts (phone,name,password,ref_code,created_at) VALUES (?,?,?,?,?)'
    ).bind(phone, name, password, ref, new Date().toISOString()).run();
    const u = await db.prepare('SELECT * FROM user_accounts WHERE phone=?').bind(phone).first();
    return cors(json(u, 201));
  }

  if (path === '/api/users/google' && method === 'POST') {
    const { google_id, name, email } = await request.json();
    let user = await db.prepare('SELECT * FROM user_accounts WHERE google_id=?').bind(google_id).first();
    if (!user) {
      user = await db.prepare('SELECT * FROM user_accounts WHERE phone=?').bind(email).first();
    }
    if (!user) {
      const ref = generateRef();
      await db.prepare(
        'INSERT INTO user_accounts (phone,name,google_id,ref_code,created_at) VALUES (?,?,?,?,?)'
      ).bind(email, name, google_id, ref, new Date().toISOString()).run();
      user = await db.prepare('SELECT * FROM user_accounts WHERE google_id=?').bind(google_id).first();
    } else if (!user.google_id) {
      await db.prepare('UPDATE user_accounts SET google_id=? WHERE id=?').bind(google_id, user.id).run();
      user = await db.prepare('SELECT * FROM user_accounts WHERE id=?').bind(user.id).first();
    }
    return cors(json(user));
  }

  if (path === '/api/users/ads' && method === 'GET') {
    const ref = url.searchParams.get('ref_code');
    if (!ref) return cors(json({ error: 'ref_code required' }, 400));
    const { results } = await db.prepare(
      'SELECT * FROM ad_submissions WHERE ref_code=? ORDER BY created_at DESC'
    ).bind(ref).all();
    return cors(json(results.map(parseProperty)));
  }

  // Boost property
  const boostMatch = path.match(/^\/api\/properties\/(\d+)\/boost$/);
  if (boostMatch && method === 'PUT') {
    const id = boostMatch[1];
    const { days } = await request.json();
    const until = new Date(Date.now() + days * 86400000).toISOString();
    await db.prepare(
      'UPDATE properties SET boosted=1, boosted_until=?, boosted_days=? WHERE id=?'
    ).bind(until, days, id).run();
    return cors(json({ ok: true }));
  }

  return cors(json({ error: 'Not found' }, 404));
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

/** Upload base64 image → R2, return the object key */
async function uploadImageToR2(bucket, dataUri, filename) {
  // dataUri can be 'data:image/jpeg;base64,...' or already a URL
  if (!dataUri || dataUri.startsWith('http')) return dataUri;
  const [meta, b64] = dataUri.split(',');
  const mime = meta.match(/:(.*?);/)[1];
  const ext = mime.split('/')[1].replace('jpeg', 'jpg');
  const key = `photos/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
  const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
  await bucket.put(key, bytes, { httpMetadata: { contentType: mime } });
  return key;
}

/** Process photos array: upload any base64 items to R2, return public URLs */
async function uploadPhotosArray(bucket, url, photos) {
  if (!photos || !photos.length) return [];
  const results = [];
  for (const p of photos) {
    if (!p) continue;
    if (p.startsWith('http') || p.startsWith('/images/')) {
      results.push(p); // already a URL, keep as-is
    } else {
      const key = await uploadImageToR2(bucket, p, 'photo.jpg');
      results.push(`${url.origin}/images/${key}`);
    }
  }
  return results;
}

/** Parse a DB row: JSON fields → arrays/objects */
function parseProperty(row) {
  if (!row) return row;
  try { if (typeof row.amenities === 'string') row.amenities = JSON.parse(row.amenities); } catch {}
  try { if (typeof row.photos === 'string') row.photos = JSON.parse(row.photos); } catch {}
  row.boosted = !!row.boosted;
  return row;
}

async function insertProperty(db, body) {
  const stmt = db.prepare(`
    INSERT INTO properties
      (type,title,location,province,price,beds,baths,area,land,land_perches,
       img,amenities,deed,badge,badge_key,description,link,listing_mode,country,
       photos,boosted,boosted_until,boosted_days,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `);
  const r = await stmt.bind(
    body.type||'house', body.title, body.location||'', body.province||'',
    body.price||0, body.beds||0, body.baths||0, body.area||'—', body.land||'—', body.land_perches||0,
    body.img||'img-custom',
    JSON.stringify(body.amenities||[]),
    body.deed||'freehold',
    body.badge||null, body.badge_key||null,
    body.description||'', body.link||null,
    body.listing_mode||'buy', body.country||'LK',
    JSON.stringify(body.photos||[]),
    body.boosted?1:0, body.boosted_until||null, body.boosted_days||0,
    body.created_at||new Date().toISOString()
  ).run();
  return r.meta?.last_row_id;
}

async function updateProperty(db, id, body) {
  await db.prepare(`
    UPDATE properties SET
      type=?,title=?,location=?,province=?,price=?,beds=?,baths=?,area=?,land=?,
      land_perches=?,img=?,amenities=?,deed=?,badge=?,badge_key=?,description=?,
      link=?,listing_mode=?,country=?,photos=?,boosted=?,boosted_until=?,boosted_days=?
    WHERE id=?
  `).bind(
    body.type, body.title, body.location, body.province||'',
    body.price, body.beds||0, body.baths||0, body.area||'—', body.land||'—', body.land_perches||0,
    body.img||'img-custom',
    JSON.stringify(body.amenities||[]),
    body.deed||'freehold',
    body.badge||null, body.badge_key||null,
    body.description||'', body.link||null,
    body.listing_mode||'buy', body.country||'LK',
    JSON.stringify(body.photos||[]),
    body.boosted?1:0, body.boosted_until||null, body.boosted_days||0,
    id
  ).run();
}

function generateRef() {
  return 'VN' + Math.random().toString(36).slice(2,8).toUpperCase();
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' }
  });
}

function cors(response) {
  const r = new Response(response.body, response);
  r.headers.set('Access-Control-Allow-Origin', '*');
  r.headers.set('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  r.headers.set('Access-Control-Allow-Headers', 'Content-Type,Authorization');
  return r;
}
