-- ============================================================
-- vino.properties — D1 Schema
-- Run this in your Cloudflare D1 console or via wrangler:
--   wrangler d1 execute VINO_DB --file=schema.sql
-- ============================================================

-- Properties (live listings)
CREATE TABLE IF NOT EXISTS properties (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  type          TEXT    NOT NULL DEFAULT 'house',
  title         TEXT    NOT NULL,
  location      TEXT    NOT NULL,
  province      TEXT,
  price         REAL    NOT NULL DEFAULT 0,
  beds          INTEGER DEFAULT 0,
  baths         INTEGER DEFAULT 0,
  area          TEXT    DEFAULT '—',
  land          TEXT    DEFAULT '—',
  land_perches  REAL    DEFAULT 0,
  img           TEXT    DEFAULT 'img-custom',
  amenities     TEXT    DEFAULT '[]',   -- JSON array
  deed          TEXT    DEFAULT 'freehold',
  badge         TEXT,
  badge_key     TEXT,
  description   TEXT    DEFAULT '',
  link          TEXT,
  listing_mode  TEXT    DEFAULT 'buy',  -- 'buy' | 'rent'
  country       TEXT    DEFAULT 'LK',
  photos        TEXT    DEFAULT '[]',   -- JSON array of R2 public URLs
  boosted       INTEGER DEFAULT 0,      -- 0 or 1
  boosted_until TEXT,                   -- ISO datetime
  boosted_days  INTEGER DEFAULT 0,
  created_at    TEXT    DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_properties_listing_mode ON properties(listing_mode);
CREATE INDEX IF NOT EXISTS idx_properties_country ON properties(country);
CREATE INDEX IF NOT EXISTS idx_properties_boosted ON properties(boosted, boosted_until);
CREATE INDEX IF NOT EXISTS idx_properties_created ON properties(created_at DESC);

-- Ad submissions (pending user ads awaiting admin approval)
CREATE TABLE IF NOT EXISTS ad_submissions (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  title            TEXT    NOT NULL,
  type             TEXT    DEFAULT 'house',
  price            REAL    DEFAULT 0,
  location         TEXT    DEFAULT '',
  province         TEXT    DEFAULT '',
  beds             INTEGER DEFAULT 0,
  baths            INTEGER DEFAULT 0,
  area             TEXT    DEFAULT '—',
  land             TEXT    DEFAULT '—',
  land_perches     REAL    DEFAULT 0,
  img              TEXT    DEFAULT 'img-custom',
  amenities        TEXT    DEFAULT '[]',  -- JSON array
  deed             TEXT    DEFAULT 'freehold',
  listing_mode     TEXT    DEFAULT 'buy',
  badge            TEXT,
  badge_key        TEXT,
  description      TEXT    DEFAULT '',
  status           TEXT    DEFAULT 'pending',  -- 'pending' | 'approved' | 'rejected'
  submitter_name   TEXT    DEFAULT '',
  submitter_phone  TEXT    DEFAULT '',
  submitter_email  TEXT    DEFAULT '',
  country          TEXT    DEFAULT 'LK',
  package_name     TEXT    DEFAULT 'basic',
  package_price    REAL    DEFAULT 2900,
  payment_ref      TEXT    DEFAULT '',
  ref_code         TEXT    UNIQUE,
  photos           TEXT    DEFAULT '[]',  -- JSON array of R2 public URLs
  created_at       TEXT    DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_sub_status ON ad_submissions(status);
CREATE INDEX IF NOT EXISTS idx_sub_ref ON ad_submissions(ref_code);
CREATE INDEX IF NOT EXISTS idx_sub_phone ON ad_submissions(submitter_phone);

-- User accounts
CREATE TABLE IF NOT EXISTS user_accounts (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  phone      TEXT    NOT NULL UNIQUE,
  name       TEXT    DEFAULT '',
  password   TEXT,
  google_id  TEXT,
  ref_code   TEXT    UNIQUE,
  created_at TEXT    DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_user_phone ON user_accounts(phone);
CREATE INDEX IF NOT EXISTS idx_user_google ON user_accounts(google_id);
CREATE INDEX IF NOT EXISTS idx_user_ref ON user_accounts(ref_code);
