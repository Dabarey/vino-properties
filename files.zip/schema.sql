-- ============================================================
-- vino.properties — Cloudflare D1 schema
-- Run with:  wrangler d1 execute vino-db --file=./worker/schema.sql
-- ============================================================

-- Properties (public listings)
CREATE TABLE IF NOT EXISTS properties (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  type          TEXT    NOT NULL DEFAULT 'house',
  title         TEXT    NOT NULL DEFAULT '',
  location      TEXT    NOT NULL DEFAULT '',
  province      TEXT    DEFAULT '',
  price         INTEGER DEFAULT 0,
  beds          INTEGER DEFAULT 0,
  baths         INTEGER DEFAULT 0,
  area          TEXT    DEFAULT '—',
  land          TEXT    DEFAULT '—',
  land_perches  INTEGER DEFAULT 0,
  img           TEXT    DEFAULT 'img-custom',
  amenities     TEXT    DEFAULT '[]',   -- JSON array stored as text
  deed          TEXT    DEFAULT 'freehold',
  badge         TEXT,
  badge_key     TEXT,
  description   TEXT    DEFAULT '',
  link          TEXT,
  photos        TEXT,                    -- JSON array of base64 strings stored as text
  listing_mode  TEXT    DEFAULT 'buy',
  country       TEXT    DEFAULT 'LK',
  views         INTEGER DEFAULT 1,
  boosted       INTEGER DEFAULT 0,       -- SQLite has no bool; 0/1
  boosted_until TEXT,
  boosted_days  INTEGER DEFAULT 0,
  created_at    TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_properties_created ON properties(created_at DESC);

-- User accounts (advertisers)
CREATE TABLE IF NOT EXISTS user_accounts (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  phone         TEXT    NOT NULL UNIQUE,
  name          TEXT    DEFAULT '',
  password_hash TEXT    NOT NULL,        -- SHA-256 hex, NOT plaintext
  ref_code      TEXT,
  created_at    TEXT    DEFAULT (datetime('now'))
);

-- Ad submissions (pending approval queue)
CREATE TABLE IF NOT EXISTS ad_submissions (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  type            TEXT,
  title           TEXT,
  location        TEXT,
  province        TEXT,
  price           INTEGER DEFAULT 0,
  beds            INTEGER DEFAULT 0,
  baths           INTEGER DEFAULT 0,
  area            TEXT,
  land            TEXT,
  land_perches    INTEGER DEFAULT 0,
  img             TEXT,
  amenities       TEXT    DEFAULT '[]',
  deed            TEXT,
  description     TEXT,
  photos          TEXT,
  submitter_name  TEXT,
  submitter_phone TEXT,
  submitter_email TEXT,
  country         TEXT    DEFAULT 'LK',
  package_name    TEXT,
  package_price   TEXT,
  payment_ref     TEXT,
  ref_code        TEXT,
  status          TEXT    DEFAULT 'pending',
  created_at      TEXT    DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_subs_status ON ad_submissions(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_subs_ref    ON ad_submissions(ref_code);
