# vino.properties — Deployment (GitHub + Cloudflare Pages + Worker + D1)

This repo has two parts:

```
public/          ← the static site (index.html, terms.html, manifest.json, sw.js)
worker/          ← the Cloudflare Worker API + D1 schema
  index.js
  schema.sql
  wrangler.toml
```

The site no longer uses Supabase. All data now lives in **Cloudflare D1**
(SQLite), reached through the **Worker** in `worker/`. The browser never
talks to the database directly — it calls the Worker's `/api/...` endpoints.

---

## 0. One-time tool setup (nothing installed yet)

Install Node.js 18+ (https://nodejs.org), then install Wrangler:

```bash
npm install -g wrangler
wrangler login        # opens browser, log into your Cloudflare account
```

---

## 1. Push this folder to GitHub

```bash
cd vino-deploy
git init
git add .
git commit -m "Migrate to Cloudflare Worker + D1"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vino-properties.git
git push -u origin main
```

---

## 2. Create the D1 database

```bash
cd worker
wrangler d1 create vino-db
```

This prints a block like:

```
[[d1_databases]]
binding = "DB"
database_name = "vino-db"
database_id = "abcd1234-...."
```

Copy the `database_id` value into `worker/wrangler.toml`, replacing
`REPLACE_WITH_YOUR_D1_DATABASE_ID`.

---

## 3. Create the tables

```bash
# from worker/
wrangler d1 execute vino-db --remote --file=./schema.sql
```

(Use `--local` instead of `--remote` to test against a local copy first.)

---

## 3b. Create the R2 bucket (for property photos)

Photos are no longer stored as base64 in the database — they're uploaded to
**R2** (object storage) and only the URL is kept in D1. Create the bucket:

```bash
# from worker/
wrangler r2 bucket create vino-photos
```

The binding is already in `wrangler.toml` (`binding = "BUCKET"`,
`bucket_name = "vino-photos"`). Nothing to paste.

**How images get served — two options:**

- **Serve through the Worker (default, zero extra setup).** Leave
  `PHOTO_BASE_URL` commented out in `wrangler.toml`. Uploaded images are
  reachable at `https://your-worker.workers.dev/r2/photos/<file>`. Simple,
  works immediately. Every image view is a Worker request.

- **Serve straight from R2 / CDN (faster, cheaper at scale).** In the
  Cloudflare dashboard → R2 → `vino-photos` → Settings, enable **Public
  access** (gives you a `https://pub-xxxx.r2.dev` URL) or attach a custom
  domain. Then uncomment and set in `wrangler.toml`:

  ```toml
  [vars]
  PHOTO_BASE_URL = "https://pub-xxxxxxxx.r2.dev"
  ```

  New uploads will use that base URL. Either option can be switched later;
  only newly-uploaded photos pick up the change.

---

## 4. Set the secrets

The admin password and a password-hashing salt are **secrets**, never
committed to git:

```bash
wrangler secret put ADMIN_PASSWORD     # type your chosen admin password
wrangler secret put AUTH_SALT          # any long random string, e.g. `openssl rand -hex 32`
```

> Keep `AUTH_SALT` stable. If you change it later, all existing user
> passwords stop matching (they'd need to reset). The admin password can be
> changed any time by re-running `wrangler secret put ADMIN_PASSWORD`.

---

## 5. Deploy the Worker

```bash
# from worker/
wrangler deploy
```

It prints your Worker URL, e.g.:

```
https://vino-api.YOUR-SUBDOMAIN.workers.dev
```

---

## 6. Point the frontend at your Worker

Open `public/index.html`, find this line near the top of the main script:

```js
const API_BASE = 'https://vino-api.YOUR-SUBDOMAIN.workers.dev';
```

Replace it with the exact URL from step 5. Commit and push:

```bash
git commit -am "Set API_BASE to deployed Worker"
git push
```

---

## 7. Host the static site on Cloudflare Pages

1. Cloudflare dashboard → **Workers & Pages** → **Create** → **Pages** →
   **Connect to Git** → pick your repo.
2. Build settings:
   - **Framework preset:** None
   - **Build command:** *(leave empty)*
   - **Build output directory:** `public`
3. **Save and Deploy.**

Your site goes live at `https://your-project.pages.dev`. Every `git push`
redeploys automatically.

> Prefer GitHub Pages? It also works — just serve the `public/` folder. But
> since the Worker is already on Cloudflare, Pages keeps everything in one
> place and lets you tighten CORS to your Pages domain later.

---

## 8. Lock down CORS (recommended, after it works)

In `worker/index.js`, the `cors()` function currently allows `*`. Once your
Pages URL is known, change:

```js
'Access-Control-Allow-Origin': '*'
```

to your real domain, e.g. `'https://your-project.pages.dev'`, then
`wrangler deploy` again.

---

## Local development

```bash
# Terminal 1 — run the Worker against a local D1
cd worker
wrangler d1 execute vino-db --local --file=./schema.sql   # once
wrangler dev --local                                       # serves http://localhost:8787

# In public/index.html temporarily set:
#   const API_BASE = 'http://localhost:8787';
# then open public/index.html (or serve it with `npx serve public`)
```

---

## What changed from the Supabase version

- **Property photos now live in R2**, not as base64 inside the database.
  When you save a listing in the admin panel, the photos are uploaded to the
  `vino-photos` bucket and only their URLs are stored in D1. Public ad
  submissions still carry their photos as data while pending (low volume,
  unpublished), and those are moved into R2 automatically when an admin
  approves the ad. This keeps `GET /api/properties` small and fast and avoids
  D1's row-size limits.
- **Passwords are hashed** (SHA-256 + server salt) in D1, not stored in
  plaintext. Existing Supabase accounts are **not** migrated — users create
  fresh accounts, or you can import them (they'd need new passwords since the
  old ones were plaintext).
- **Admin password is a server secret**, not a value in browser localStorage.
  The in-app "change password" field now tells you to use `wrangler secret put`.
- **Admin-only actions** (create/edit/delete property, view & approve/reject
  pending ads, boost) require the admin token and are enforced **server-side**.
- The PayPal client ID in `index.html` is unchanged — that one is meant to be
  public. Review it if it was a sandbox/test ID.

## API reference (implemented in worker/index.js)

| Method | Path                          | Auth   | Purpose                          |
|--------|-------------------------------|--------|----------------------------------|
| GET    | /api/properties               | public | list all properties              |
| POST   | /api/upload                   | admin  | upload photos to R2, returns URLs|
| GET    | /r2/:key                      | public | serve an R2 image (Worker mode)  |
| POST   | /api/properties               | admin  | create property                  |
| PUT    | /api/properties/:id           | admin  | update property (also boost)     |
| DELETE | /api/properties/:id           | admin  | delete property                  |
| POST   | /api/submissions              | public | submit ad for approval           |
| GET    | /api/submissions/pending      | admin  | list pending ads                 |
| GET    | /api/submissions/by-ref       | public | a user's submissions by ref_code |
| POST   | /api/submissions/approve      | admin  | approve → publish                |
| POST   | /api/submissions/reject       | admin  | reject                           |
| POST   | /api/boost                    | public | boost/repost by ref_code         |
| POST   | /api/account/create           | public | create/refresh advertiser account|
| POST   | /api/account/login            | public | advertiser login                 |
| POST   | /api/admin/login              | public | exchange password for admin token|
