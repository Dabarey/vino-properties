export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    let path = url.pathname;

    // Default to index.html for root
    if (path === '/' || path === '') {
      path = '/index.html';
    }

    // Remove leading slash for R2 key
    const key = path.replace(/^\//, '');

    const object = await env.BUCKET.get(key);

    if (!object) {
      // Try index.html fallback for SPA-style routing
      const fallback = await env.BUCKET.get('index.html');
      if (!fallback) {
        return new Response('Not Found', { status: 404 });
      }
      return new Response(fallback.body, {
        headers: {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': 'no-cache',
        }
      });
    }

    // MIME types
    const mimeTypes = {
      'html': 'text/html; charset=utf-8',
      'css':  'text/css',
      'js':   'application/javascript',
      'json': 'application/json',
      'png':  'image/png',
      'jpg':  'image/jpeg',
      'svg':  'image/svg+xml',
      'ico':  'image/x-icon',
      'webp': 'image/webp',
      'woff': 'font/woff',
      'woff2':'font/woff2',
    };

    const ext = key.split('.').pop().toLowerCase();
    const contentType = mimeTypes[ext] || 'application/octet-stream';

    const headers = {
      'Content-Type': contentType,
      'Cache-Control': key === 'sw.js' ? 'no-cache' : 'public, max-age=31536000',
    };

    // Service worker needs this header
    if (key === 'sw.js') {
      headers['Service-Worker-Allowed'] = '/';
    }

    return new Response(object.body, { headers });
  }
};
